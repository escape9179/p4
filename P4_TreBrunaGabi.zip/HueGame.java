/*Main code for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HueGame extends JFrame {
    public final int gridSize = 6; //6x6 grid, we can update this and code will still work, but the bigger, the harder to see the color difference of each grid
    public ColorGrid grid; //color tile
    public boolean gameWon = false; //game is not won yet
    private Player player1, player2; //players in multiplayer mode
    private Player currentPlayer; // current players turn
    private long startTime; //time in milliseconds to track scores

    public HueGame() { //displays game
        showWelcomeScreen();
        setVisible(true);
    }

    private void showWelcomeScreen() {
        //reset all game variables
        player1 = null;
        player2 = null;
        currentPlayer = null;
        gameWon = false;
        grid = null;  //clear grid to ensure a fresh start for the next game

        getContentPane().removeAll();
        setTitle("Color Gradient Game");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 700);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("Welcome to Color Gradient!", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        JTextArea rules = new JTextArea("\n In this game, your goal is to arrange the color tiles to form a smooth gradient like the one shown here.\n How? Simple, click two tiles to swap them until you reach the final gradient.\n ps.: you may want to keep a picture of it by your side for reference.\n Good Luck!");
        rules.setFont(new Font("Serif", Font.PLAIN, 18));
        rules.setEditable(false);
        rules.setLineWrap(true);
        rules.setWrapStyleWord(true);
        add(rules, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();

        JButton singlePlayerButton = new JButton("Single Player");
        singlePlayerButton.setFont(new Font("Serif", Font.BOLD, 20));
        singlePlayerButton.setBackground(Color.DARK_GRAY); //button color settings
        singlePlayerButton.setForeground(Color.WHITE); //button text color
        singlePlayerButton.addActionListener(e -> startSinglePlayerGame());

        JButton multiplayerButton = new JButton("Multiplayer");
        multiplayerButton.setFont(new Font("Serif", Font.BOLD, 20));
        multiplayerButton.setBackground(Color.DARK_GRAY);
        multiplayerButton.setForeground(Color.WHITE);
        multiplayerButton.addActionListener(e -> showMultiplayerSetup());

        buttonPanel.add(singlePlayerButton);
        buttonPanel.add(multiplayerButton);
        add(buttonPanel, BorderLayout.SOUTH);

        //gradient preview panel
        JPanel previewPanel = new JPanel();
        previewPanel.setPreferredSize(new Dimension(300, 200)); //panel size
        previewPanel.setLayout(new GridLayout(6, 6)); //grid size
        for (int i = 0; i < 36; i++) { //this loop creates the color gradient effect, chosing spcific colors for each grid
            float hue = (float) i / 36;
            Color color = Color.getHSBColor(hue, 1.0f, 1.0f);
            JPanel colorPanel = new JPanel();
            colorPanel.setBackground(color);
            previewPanel.add(colorPanel);
        }

        JPanel previewContainer = new JPanel(new BorderLayout());
        previewContainer.add(new JLabel("Goal Gradient Reference", SwingConstants.CENTER), BorderLayout.NORTH);
        previewContainer.add(previewPanel, BorderLayout.CENTER);
        add(previewContainer, BorderLayout.EAST);

        revalidate();
        repaint();
    }

    private void showMultiplayerSetup() { //new screen that asks for users names as input and starts the multiplayer game
        getContentPane().removeAll();
        setLayout(new BorderLayout());

        //title
        JLabel title = new JLabel("Multiplayer Setup", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        //text area for rules
        JTextArea multiRules = new JTextArea("\n Please enter both players' names below. You will know when it is your turn to play, and you will compete for the fastest completion! \n Good Luck!");
        multiRules.setFont(new Font("Serif", Font.PLAIN, 18));
        multiRules.setEditable(false);
        multiRules.setLineWrap(true);
        multiRules.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(multiRules);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        add(scrollPane, BorderLayout.CENTER);

        //input panel for Player names with GridBagLayout for better control (I found out how to use this online)
        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); //padding around boxes for visual improvement
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        //Player 1 label and text field
        JLabel player1Label = new JLabel("Player 1 Name:");
        player1Label.setFont(new Font("Serif", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(player1Label, gbc);

        JTextField player1NameField = new JTextField();
        player1NameField.setPreferredSize(new Dimension(200, 30)); //sets size of input area
        player1NameField.setFont(new Font("Serif", Font.PLAIN, 16));
        gbc.gridx = 1;
        inputPanel.add(player1NameField, gbc);

        //Player 2 label and text field
        JLabel player2Label = new JLabel("Player 2 Name:");
        player2Label.setFont(new Font("Serif", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(player2Label, gbc);

        JTextField player2NameField = new JTextField();
        player2NameField.setPreferredSize(new Dimension(200, 30));
        player2NameField.setFont(new Font("Serif", Font.PLAIN, 16));
        gbc.gridx = 1;
        inputPanel.add(player2NameField, gbc);

        //start game button
        JButton startMultiplayerButton = new JButton("Start Multiplayer Game");
        startMultiplayerButton.setFont(new Font("Serif", Font.BOLD, 16));
        startMultiplayerButton.setBackground(Color.DARK_GRAY);
        startMultiplayerButton.setForeground(Color.WHITE);
        startMultiplayerButton.addActionListener(e -> {
            player1 = new Player(player1NameField.getText());
            player2 = new Player(player2NameField.getText());
            currentPlayer = player1; //set the first player
            startMultiplayerGame();  //call the start method
        });
        //more layout edits
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(startMultiplayerButton, gbc);

        add(inputPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    private void startSinglePlayerGame() {
        System.out.println("Starting single player game...");  //debug print to command line
        gameWon = false;  //fresh game for single player
        player1 = new Player("Single Player");
        currentPlayer = player1;
        
        //initializes grid
        grid = new ColorGrid(gridSize);
        grid.shuffleTiles();
        
        startGame();
    }

    private void startMultiplayerGame() {
        gameWon = false;  //resets gameWon for multiplayer
        grid = new ColorGrid(gridSize);  //fresh grid
        grid.shuffleTiles();
        currentPlayer = player1;  //starts with player1
        startGame();
    }

    private void startGame() { //starts the game, gets grid size and sets up the random shuffle of the gradient 
        getContentPane().removeAll();
        setLayout(new BorderLayout());

        JLabel playerLabel = new JLabel(currentPlayer.getName() + "'s Turn", SwingConstants.CENTER);
        playerLabel.setFont(new Font("Serif", Font.BOLD, 24));
        add(playerLabel, BorderLayout.NORTH);

        JPanel gamePanel = new JPanel(new GridLayout(gridSize, gridSize));

        for (int i = 0; i < gridSize * gridSize; i++) {
            ColorTileButton button = new ColorTileButton(grid.getTile(i));
            button.addActionListener(new TileClickListener(this, button, i, currentPlayer));
            gamePanel.add(button);
        }
        add(gamePanel, BorderLayout.CENTER);

        startTimer();
        revalidate();
        repaint();
    }

    private void startTimer() { //added a timer for competition between players in multiplayer mode
        startTime = System.currentTimeMillis();
    }

    public void endGameForPlayer(Player player) { //defines how each game works (single/multi)
        if (gameWon) return;
        gameWon = true;

        long endTime = System.currentTimeMillis();
        player.setTimeTaken((endTime - startTime) / 1000);

        JOptionPane.showMessageDialog(this, "Congratulations, " + player.getName() + "! You've completed the gradient.");

        if (player == player1 && player2 != null) {
            //multiplayer mode: switch to player2
            currentPlayer = player2;
            gameWon = false; //resets gameWon
            
            //re-shuffle the grid for player2's fresh game start
            grid.shuffleTiles();
            
            startGame(); //start player2’s turn with a new shuffled grid
        } else if (player == player1 && player2 == null) {
            //single player mode: return to main screen
            showWelcomeScreen();
        } else {
            //multiplayer mode: both players completed, show results screen
            showResultsScreen();
        }
    }

    public void refreshGrid() {
        getContentPane().removeAll();
        setLayout(new GridLayout(gridSize, gridSize)); //sets new grid

        for (int i = 0; i < gridSize * gridSize; i++) { //and its colors for gradient
            ColorTileButton button = new ColorTileButton(grid.getTile(i));
            button.addActionListener(new TileClickListener(this, button, i, currentPlayer));
            add(button);
        }

        revalidate();
        repaint();
    }

    private void showResultsScreen() { //for multiplayer, to see who won
        getContentPane().removeAll();
        setLayout(new BorderLayout());

        JLabel resultsTitle = new JLabel("Game Over!", SwingConstants.CENTER);
        resultsTitle.setFont(new Font("Serif", Font.BOLD, 24));
        add(resultsTitle, BorderLayout.NORTH);

        //prints results
        String resultMessage = player1.getName() + " Time: " + player1.getTimeTaken() + " seconds\n" +
                               player2.getName() + " Time: " + player2.getTimeTaken() + " seconds\n\n";

        if (player1.getTimeTaken() < player2.getTimeTaken()) { //less time==win, same==tie
            resultMessage += player1.getName() + " wins!";
        } else if (player2.getTimeTaken() < player1.getTimeTaken()) {
            resultMessage += player2.getName() + " wins!";
        } else {
            resultMessage += "It's a tie!";
        }
        //text area for result display
        JTextArea resultText = new JTextArea(resultMessage);
        resultText.setFont(new Font("Serif", Font.PLAIN, 18));
        resultText.setEditable(false);
        resultText.setLineWrap(true);
        resultText.setWrapStyleWord(true);
        add(resultText, BorderLayout.CENTER);

        JButton mainMenuButton = new JButton("Return to Main Menu"); //to start again if wanted
        mainMenuButton.addActionListener(e -> showWelcomeScreen());
        mainMenuButton.setBackground(Color.DARK_GRAY);
        mainMenuButton.setForeground(Color.WHITE);
        add(mainMenuButton, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    public static void main(String[] args) { //calls main, starts game
        SwingUtilities.invokeLater(HueGame::new);
    }
}
