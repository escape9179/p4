/*code representing a sinlge tile for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
import java.awt.Color;

public class ColorTile {
    private final Color color;
    private final int originalPosition;

    public ColorTile(Color color, int originalPosition) {
        this.color = color;
        this.originalPosition = originalPosition;
    }

    //returns the color
    public Color getColor() {
        return color;
    }

    //returns the original position of the tile
    public int getOriginalPosition() {
        return originalPosition;
    }
}
