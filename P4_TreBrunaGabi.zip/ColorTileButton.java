/*makes the tile a button for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
import javax.swing.*;
import java.awt.*;

public class ColorTileButton extends JButton {
    private ColorTile tile;

    public ColorTileButton(ColorTile tile) {
        this.tile = tile;
        updateColor();
        setFocusPainted(false);
        setBorder(BorderFactory.createEmptyBorder());
    }

    //matches color button to tile's
    public void updateColor() {
        setBackground(tile.getColor());
    }

    public void setTile(ColorTile newTile) {
        this.tile = newTile;
        updateColor();
    }
}
