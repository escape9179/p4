/*Color grid code for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//manages generation and shuffling
public class ColorGrid {
    private final int gridSize;  //grid dimensions
    private final List<ColorTile> tiles;  //all tiles in the grid

    //initializes grid with size and fills it with gradient tiles
    public ColorGrid(int gridSize) {
        this.gridSize = gridSize;
        this.tiles = new ArrayList<>();
        generateGradientTiles();
    }

    //generates a color gradient for the tiles
    private void generateGradientTiles() {
        for (int i = 0; i < gridSize * gridSize; i++) {
            float hue = (float) i / (gridSize * gridSize);  //hue for each tile
            Color color = Color.getHSBColor(hue, 1.0f, 1.0f);  //create color from hue
            tiles.add(new ColorTile(color, i));  //add tile with color and position
        }
    }

    //shuffles tiles until out of correct order
    public void shuffleTiles() {
        do {
            Collections.shuffle(tiles);
        } while (isCorrectOrder());  //ensures is not the solution
    }

    //checks if all tiles are in their original order
    public boolean isCorrectOrder() {
        for (int i = 0; i < tiles.size(); i++) {
            if (tiles.get(i).getOriginalPosition() != i) {  //returns false if a tile is out of place
                return false;
            }
        }
        return true; //until all is true
    }

    //gets at a specific index
    public ColorTile getTile(int index) {
        return tiles.get(index);
    }

    //swaps two tiles in the grid
    public void swapTiles(int index1, int index2) {
        ColorTile temp = tiles.get(index1);
        tiles.set(index1, tiles.get(index2));
        tiles.set(index2, temp);
    }
}
