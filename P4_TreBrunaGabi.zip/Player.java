/*Player class for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
public class Player {
    private final String name;
    private long timeTaken; // for score tracking

    public Player(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public long getTimeTaken() {
        return timeTaken;
    }

    public void setTimeTaken(long timeTaken) {
        this.timeTaken = timeTaken;
    }
}
