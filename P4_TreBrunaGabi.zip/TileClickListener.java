/*Handles click actions for the color gradient game. 
 *P4 program- Tre, Bruna, and Gabi.
 *CS208
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import java.awt.Color;

public class TileClickListener implements ActionListener {
    private final HueGame game;
    private final ColorTileButton button;
    private final int index;
    private final Player player;
    private static ColorTileButton selectedButton = null;
    private static int selectedIndex = -1;

    public TileClickListener(HueGame game, ColorTileButton button, int index, Player player) {
        this.game = game;
        this.button = button;
        this.index = index;
        this.player = player;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (game.gameWon) {
            return; //stops if game is already won
        }

        //selection and swap logic
        if (selectedButton == null) {
            selectedButton = button;
            selectedIndex = index;
            button.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        } else {
            game.grid.swapTiles(selectedIndex, index);
            selectedButton.setBorder(null);
            selectedButton = null;
            selectedIndex = -1;
            game.refreshGrid();

            //check if the player has won after each swap
            if (!game.gameWon && game.grid.isCorrectOrder()) {
                game.endGameForPlayer(player);
            }
        }
    }
}
