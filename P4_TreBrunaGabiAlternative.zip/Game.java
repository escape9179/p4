// GameMap.java
// Created by Bruna Ruby Andreotti
// This class manages the mapping of players to rooms using a HashMap. It includes methods for adding players to rooms, moving them, and removing them.

import java.util.HashMap;
import java.util.Map;

public class Game {
    private Map<String, Room> rooms; // Map of room names to Room objects
    private Map<Player, Room> playerRoomMap; // Map of players to their current room

    public Game() {
        rooms = new HashMap<>();
        playerRoomMap = new HashMap<>();
        // Initialize rooms
        rooms.put("Main Hall", new Room("Main Hall"));
        rooms.put("Garden", new Room("Garden"));
        rooms.put("Bedroom", new Room("Bedroom"));
        rooms.put("Kitchen", new Room("Kitchen"));
    }

    // Adds a player to a room
    public void addPlayerToRoom(Player player, String roomName) {
        Room room = rooms.get(roomName);
        if (room != null && !playerRoomMap.containsKey(player)) {
            room.addPlayer(player);
            playerRoomMap.put(player, room);
        }
    }

    // Moves a player from one room to another
    public void movePlayer(Player player, String newRoomName) {
        Room currentRoom = playerRoomMap.get(player);
        Room newRoom = rooms.get(newRoomName);

        if (currentRoom != null && newRoom != null) {
            currentRoom.removePlayer(player); // Remove from current room
            newRoom.addPlayer(player); // Add to new room
            playerRoomMap.put(player, newRoom); // Update the player's room
        }
    }

    // Removes a player from the game and their room
    public boolean removePlayer(Player player) {
        Room room = playerRoomMap.remove(player);
        if (room != null) {
            room.removePlayer(player);
            return true;
        }
        return false;
    }

    public Room getRoom(String roomName) {
        return rooms.get(roomName);
    }

    public Map<String, Room> getAllRooms() {
        return rooms;
    }

    public boolean isPlayerInGame(Player player) {
        return playerRoomMap.containsKey(player);
    }
}
