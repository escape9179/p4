// GameGUI.java
// Created by Bruna Ruby Andreotti
// This is a basic GUI simulator that interacts with the GameMap class. It allows adding, moving, and deleting players in rooms.

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

public class GameGUI {
    private static Game game = new Game();
    private static JTextArea playerRoomDisplay;
    private static JComboBox<String> roomComboBox;
    private static JTextField playerNameField;
    private static JTextField movePlayerNameField;
    private static JTextField deletePlayerNameField;
    private static JTextArea instructionsArea;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Castle Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 650); // Adjusted size for more space

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Instructions Panel
        instructionsArea = new JTextArea(5, 20);
        instructionsArea.setEditable(false);
        instructionsArea.setText("Welcome to the Castle Game!\n\n" +
                                  "1. Enter a player name and select a room.\n" +
                                  "2. Click 'Add Player to Room' to add the player.\n" +
                                  "3. To move a player, enter their name under 'Move Player' and select a new room.\n" +
                                  "4. To delete a player, enter their name and click 'Delete Player'.\n" +
                                  "5. The list of players in each room will be shown below.\n");
        instructionsArea.setBackground(Color.LIGHT_GRAY);
        panel.add(instructionsArea, BorderLayout.NORTH);

        // Main panel for actions
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2, 10, 10)); // Increase rows to 6
        inputPanel.setBorder(BorderFactory.createTitledBorder("Player Actions"));

        inputPanel.add(new JLabel("Player Name:"));
        playerNameField = new JTextField();
        inputPanel.add(playerNameField);

        inputPanel.add(new JLabel("Room Name:"));
        roomComboBox = new JComboBox<>(new String[] { "Main Hall", "Garden", "Bedroom", "Kitchen" });
        inputPanel.add(roomComboBox);
        inputPanel.add(new JLabel("")); //didnt know how else to add space to create a better layout, so added an empty panel

        JButton addButton = new JButton("Add Player to Room");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPlayerToRoom();
            }
        });

        inputPanel.add(addButton);

        // Move Player Section
        inputPanel.add(new JLabel("Move Player to Room:"));
        movePlayerNameField = new JTextField();
        inputPanel.add(movePlayerNameField);

        JButton moveButton = new JButton("Move Player");
        moveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                movePlayer();
            }
        });
        inputPanel.add(moveButton);

        // Delete Player Section
        
        inputPanel.add(new JLabel("Delete Player:"));
        deletePlayerNameField = new JTextField();
        inputPanel.add(deletePlayerNameField);

        JButton deleteButton = new JButton("Delete Player");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletePlayer();
            }
        });
        inputPanel.add(deleteButton);

        panel.add(inputPanel, BorderLayout.CENTER);

        // Display area for showing players in a room
        playerRoomDisplay = new JTextArea(10, 30);
        playerRoomDisplay.setEditable(false);
        playerRoomDisplay.setBackground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(playerRoomDisplay);
        panel.add(scrollPane, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setVisible(true);
    }

    private static void addPlayerToRoom() {
        String playerName = playerNameField.getText();
        String roomName = (String) roomComboBox.getSelectedItem();

        if (playerName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Player name cannot be empty.");
            return;
        }

        Player player = new Player(playerName);
        game.addPlayerToRoom(player, roomName);
        updateDisplay();
        JOptionPane.showMessageDialog(null, playerName + " has been added to " + roomName + ".");
    }

    private static void movePlayer() {
        String playerName = movePlayerNameField.getText();
        String roomName = (String) roomComboBox.getSelectedItem();

        if (playerName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Player name cannot be empty.");
            return;
        }

        Player player = new Player(playerName);

        if (!game.isPlayerInGame(player)) {
            JOptionPane.showMessageDialog(null, "Player " + playerName + " does not exist in the game.");
            return;
        }

        game.movePlayer(player, roomName);
        updateDisplay();
        JOptionPane.showMessageDialog(null, playerName + " has been moved to " + roomName + ".");
    }

    private static void deletePlayer() {
        String playerName = deletePlayerNameField.getText();

        if (playerName.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Player name cannot be empty.");
            return;
        }

        Player player = new Player(playerName);

        boolean success = game.removePlayer(player);
        if (success) {
            updateDisplay();
            JOptionPane.showMessageDialog(null, playerName + " has been deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "Player " + playerName + " not found.");
        }
    }

    private static void updateDisplay() {
        playerRoomDisplay.setText("");  // Clear the display area

        // Iterate over all rooms and display players in each room
        for (Map.Entry<String, Room> entry : game.getAllRooms().entrySet()) {
            Room room = entry.getValue();
            playerRoomDisplay.append("Players in " + room.getRoomName() + ":\n");

            for (Player player : room.getPlayersInRoom()) {
                playerRoomDisplay.append("- " + player.getName() + "\n");
            }
            playerRoomDisplay.append("\n");
        }
    }
}