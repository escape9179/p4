// Room.java
// Created by Bruna Ruby Andreotti
// This class represents a room in the castle where players can visit. It holds the name of the room and the list of players in the room.

import java.util.ArrayList;
import java.util.List;

public class Room {
    private String roomName;
    private List<Player> playersInRoom;

    public Room(String roomName) {
        this.roomName = roomName;
        this.playersInRoom = new ArrayList<>();
    }

    public String getRoomName() {
        return roomName;
    }

    public List<Player> getPlayersInRoom() {
        return playersInRoom;
    }

    public void addPlayer(Player player) {
        if (!playersInRoom.contains(player)) {
            playersInRoom.add(player);
        }
    }

    public void removePlayer(Player player) {
        playersInRoom.remove(player);
    }
}
